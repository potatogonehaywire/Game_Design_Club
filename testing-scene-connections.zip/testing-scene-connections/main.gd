# The scene that creates a 

extends Node

@export var child_scene: PackedScene

var child_id_counter = 0


signal main_TO_child_scene_to_instance

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$Timer.start() # Replace with function body.

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_timer_timeout() -> void:
	if child_id_counter < 10:
		$Timer.start()
		# Create an instance of a child scene to instance
		var child = child_scene.instantiate()
		child.id = child_id_counter
		child_id_counter = child_id_counter + 1
		add_child(child)
	print("\n----------------------------")
	print("timer timeout - main sending test message out")
	main_TO_child_scene_to_instance.emit(["instance id to send to goes here", "topic (equivalent of a function name) goes here", ["contents go here", "more contents go here"]])
