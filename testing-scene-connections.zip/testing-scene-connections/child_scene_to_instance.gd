extends Node

@export var id: int

signal child_scene_to_instance_TO_main

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	get_parent().connect("main_TO_child_scene_to_instance", _received_message_from_main)

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
	
func _received_message_from_main(message: Array):
	print("------------------------")
	print("Child number ", id, " received message with following contents:")
	print("ID of the instance that has been messaged (this information is at index 0 and you can get other instances to ignore the message if you want): ", message[0])
	print("Message topic (you can run different \"functions\" depending on the topic): ", message[1])
	print("Message contents are below:")
	for item_number in range(len(message[2])):
		print("Index: ", item_number, " Datum: ", message[item_number])
